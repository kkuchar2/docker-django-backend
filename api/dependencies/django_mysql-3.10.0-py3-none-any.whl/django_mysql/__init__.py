default_app_config = "django_mysql.apps.MySQLConfig"
